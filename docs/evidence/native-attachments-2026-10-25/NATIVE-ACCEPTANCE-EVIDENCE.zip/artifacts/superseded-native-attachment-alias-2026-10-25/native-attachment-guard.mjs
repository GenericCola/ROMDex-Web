import assert from 'node:assert/strict';
export const tenant = 'https://thegobindsingh.youtrack.cloud';
export const alias = 'PMON-900001';
export const metadataFields = 'id,name,size,mimeType,created,updated,author(id),removed,draft';
export const createGuard = ({ browser, fixture, run }) => {
  assert.ok((browser === 'chromium' && fixture === 'NPCD-872') || (browser === 'firefox' && fixture === 'NPCD-873'));
  assert.match(run, /^[a-z0-9][a-z0-9-]{0,39}$/);
  const name = `romdex-native-${fixture.toLowerCase()}-${run}.txt`;
  const bytes = Buffer.from(`ROMDex native attachment acceptance\n${fixture}\n${run}\n`);
  const base = `/api/issues/${alias}/attachments`;
  const state = { baseline: false, posts: 0, deletes: 0, receipt: null, account: null, armed: false, halted: false };
  const files = new Set();
  const fail = () => { state.halted = true; throw Error('Native guard refused request or response.'); };
  const require = (condition) => { if (!condition) fail(); };
  const query = (url, expected) => require(url.searchParams.size === Object.keys(expected).length && Object.entries(expected).every(([key,value]) => url.searchParams.getAll(key).length === 1 && url.searchParams.get(key) === value));
  const authorize = ({ url: raw, method, contentType = '', body, redirected = false }) => {
    require(!state.halted && !redirected);
    const url = new URL(raw);
    require(url.origin === tenant && !url.username && !url.password && !url.hash);
    if (method === 'GET' && url.pathname === '/api/users/me') { query(url,{fields:'id'}); return { url: raw, kind: 'account' }; }
    if (method === 'GET' && files.has(url.href)) return {url:raw,kind:'file'};
    require(url.pathname === base || (state.receipt && url.pathname === `${base}/${state.receipt}`));
    if (method === 'GET') {
      if (url.pathname === base) query(url,{fields:metadataFields,'$top':'100','$skip':'0'});
      else query(url,{fields:metadataFields+',url'});
    } else if (method === 'POST') {
      require(url.pathname === base && state.baseline && state.account && state.posts === 0 && !state.receipt);
      query(url,{fields:'id'});
      const match = /^multipart\/form-data; boundary=([A-Za-z0-9'-]{1,100})$/.exec(contentType);
      require(match && Buffer.isBuffer(body));
      const boundary = match[1];
      const expected = Buffer.concat([Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="upload"; filename="${name}"\r\nContent-Type: text/plain\r\n\r\n`),bytes,Buffer.from(`\r\n--${boundary}--\r\n`)]);
      // Browser multipart encoders may omit only the final CRLF.
      require(body.equals(expected) || body.equals(expected.subarray(0,expected.length-2)));
      state.posts++;
    } else if (method === 'DELETE') {
      require(state.armed && state.posts === 1 && state.receipt && url.pathname === `${base}/${state.receipt}` && state.deletes === 0 && !url.search && !body);
      state.deletes++; state.armed = false;
    } else fail();
    url.pathname = url.pathname.replace(alias, fixture);
    return {url:url.href,kind:method === 'GET' ? (url.pathname.endsWith('/attachments') ? 'inventory':'metadata') : method.toLowerCase()};
  };
  const observe = ({ kind, status, value }) => {
    require(!state.halted && status >= 200 && status < 300);
    if (kind === 'account') { require(value && typeof value.id === 'string' && /^[\w-]{1,100}$/.test(value.id)); state.account = value.id; }
    if (kind === 'inventory') {
      require(Array.isArray(value));
      if (!state.posts) { require(value.length === 0); state.baseline = true; }
      else if (state.deletes) { require(value.length === 0); state.deletedInventory = true; }
      else require(value.length === 1 && value[0].id === state.receipt && value[0].name === name && value[0].size === bytes.length && value[0].author?.id === state.account && !value[0].removed && !value[0].draft);
    }
    if (kind === 'post') { require(state.posts === 1 && !state.receipt && Array.isArray(value) && value.length === 1 && /^\d+-\d+$/.test(value[0]?.id)); state.receipt = value[0].id; }
    if (kind === 'metadata') {
      require(value?.id === state.receipt && value.name === name && value.size === bytes.length && value.author?.id === state.account && !value.removed && !value.draft && typeof value.url === 'string');
      const url = new URL(value.url,tenant);
      require(url.origin === tenant && !url.username && !url.password && !url.hash && /^\/(?:youtrack\/)?api\/files\/[^/]+/.test(url.pathname));
      files.add(url.href);
    }
  };
  const armDelete = (id) => { require(!state.halted && id === state.receipt && !!id && state.deletes === 0); state.armed = true; };
  return {name,bytes,state,authorize,observe,armDelete,halt:()=>{state.halted=true;}};
};

