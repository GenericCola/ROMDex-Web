// Explicit manual acceptance only. Never imported by application or default suites.
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';
import { chromium, firefox, expect } from '@playwright/test';
import { createGuard, tenant, alias } from './native-attachment-guard.mjs';
const origin = 'https://romdex-web.vercel.app';
const source = '36e748eaad7e360974c62c392a61c639ae19f804';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
let browser, context, page, guard, output;
let phase = 'arguments';
const evidence = { source, syntheticTaskContext: true, nativeAcceptance: 'UNRUN', messages: [], receipts: [] };
const main = async () => {
  assert.ok(!process.env.DEBUG && !process.env.PWDEBUG && !process.env.NODE_DEBUG);
  const args = process.argv.slice(2);
  assert.equal(args.length,8);
  const options = {};
  for(let i=0;i<args.length;i+=2) { assert.ok(['--browser','--fixture','--run','--output'].includes(args[i]) && !(args[i] in options)); options[args[i]]=args[i+1]; }
  guard = createGuard({browser:options['--browser'],fixture:options['--fixture'],run:options['--run']});
  const proposedOutput=resolve(options['--output']); await mkdir(proposedOutput); output=proposedOutput; // Existing evidence directories are never overwritten.
  Object.assign(evidence,{browser:options['--browser'],fixture:options['--fixture'],run:options['--run'],file:guard.name,sha256:hash(guard.bytes)});
  await writeFile(join(output,guard.name),guard.bytes,{flag:'wx'});
  phase='stdin';
  let token='';
  for await(const chunk of process.stdin) { token+=chunk.toString(); assert.ok(token.length<=8192); }
  token=token.trim(); assert.ok(token && !/[\r\n]/.test(token));
  phase='launch';
  browser=await ({chromium,firefox}[options['--browser']]).launch({headless:true});
  evidence.browserVersion=browser.version();
  context=await browser.newContext({serviceWorkers:'block',acceptDownloads:true});
  page=await context.newPage(); page.setDefaultTimeout(20000);
  const routes=new Map();
  const raw={id:'2-900001',idReadable:alias,summary:'Synthetic attachment transport fixture',description:'Synthetic context only; native attachment transport maps to '+options['--fixture'],updated:1,project:{shortName:'PMON'},parent:{issues:[]},customFields:['Type','State','Priority','Complexity'].map((name,index)=>({id:'92-'+index,name,$type:name==='State'?'StateIssueCustomField':'SingleEnumIssueCustomField',value:name==='Complexity'?null:{name:name==='State'?'Done':name==='Priority'?'Normal':'Task'}})),commentsCount:0,comments:[]};
  await context.exposeBinding('__nativeAttachmentObserved',async (_,{url,method,status,value,type})=>{
    try {
      const kind=routes.get(method+' '+url); assert.ok(kind); assert.equal(type,'cors');
      guard.observe({kind,status,value});
      evidence.receipts.push({kind,method,status,cors:type,path:kind==='file'?'[exact registered file address]':new URL(url).pathname.replace(alias,options['--fixture']),...(kind==='post'?{id:guard.state.receipt}:{}),...(kind==='account'?{accountId:guard.state.account}:{}),...(kind==='metadata'?{metadata:{id:value.id,name:value.name,size:value.size,mimeType:value.mimeType,created:value.created,updated:value.updated,authorId:value.author.id}}:{})});
    } catch { guard.halt(); throw Error('Native acceptance stopped.'); }
  });
  // Wait for native metadata registration before returning the original Response to the app.
  // No response is substituted; browser fetch must pass actual origin CORS first.
  await context.addInitScript(({tenant,alias})=>{
    const original=window.fetch.bind(window);
    window.fetch=async(input,init)=>{
      const url=new URL(typeof input==='string'?input:input.url,location.href);
      const method=init?.method||'GET';
      if(url.origin===tenant && url.pathname!=='/api/issues' && url.pathname!=='/api/issues/'+alias && (init?.redirect!=='error'||init?.credentials!=='omit')) throw Error('Native transport policy refused.');
      const response=await original(input,init);
      if(url.origin===tenant && (url.pathname==='/api/users/me'||url.pathname.startsWith('/api/issues/'+alias+'/attachments')||/^\/(?:youtrack\/)?api\/files\//.test(url.pathname))) {
        const value=method==='DELETE'||/^\/(?:youtrack\/)?api\/files\//.test(url.pathname)?null:await response.clone().json();
        await window.__nativeAttachmentObserved({url:url.href,method,status:response.status,value,type:response.type});
      }
      return response;
    };
  },{tenant,alias});
  await context.route('**/*',async route=>{
    const request=route.request(),url=new URL(request.url()),method=request.method();
    try {
      assert.ok(!guard.state.halted && !request.redirectedFrom());
      if(url.origin===origin && method==='GET') { await route.continue(); return; }
      assert.equal(url.origin,tenant);
      if(method==='GET' && (url.pathname==='/api/issues'||url.pathname==='/api/issues/'+alias)) {
        assert.ok(!url.username&&!url.password&&!url.hash);
        await route.fulfill({status:200,contentType:'application/json',headers:{'access-control-allow-origin':origin},body:JSON.stringify(url.pathname==='/api/issues'?[raw]:raw)});return;
      }
      const allowed=guard.authorize({url:url.href,method,contentType:request.headers()['content-type']||'',body:request.postDataBuffer(),redirected:!!request.redirectedFrom()});
      routes.set(method+' '+url.href,allowed.kind);
      await route.continue({url:allowed.url});
    } catch { guard.halt(); evidence.guardRefused=true; await route.abort('blockedbyclient'); }
  });
  const button=name=>page.getByRole('button',{name,exact:true});
  const message=async text=>{await expect(page.getByText(text,{exact:true})).toBeVisible();assert.ok(!guard.state.halted);evidence.messages.push(text);};
  const download=async(label,destination)=>{const pending=page.waitForEvent('download');pending.catch(()=>{});await button(label).click();const item=await pending;await item.saveAs(join(output,destination));return readFile(join(output,destination));};
  const screenshot=async name=>{for(const label of ['YouTrack Permanent Token','Session token for delivery']) {const field=page.getByLabel(label,{exact:true});if(await field.count())await field.fill('');}await page.screenshot({path:join(output,name),fullPage:true});};
  phase='synthetic task setup';await page.goto(origin);await expect(page.getByRole('switch',{name:'Auto-Sync Data',exact:true})).not.toBeChecked();await button('Connection Details').click();
  await page.getByLabel('YouTrack Permanent Token',{exact:true}).fill('synthetic-context-only');await button('Read YouTrack Tasks').click();await button('Save 1 Tasks in This Browser').click();
  await button(raw.summary).last().click();
  phase='disconnected stage';await page.getByLabel('Stage a file',{exact:true}).setInputFiles({name:guard.name,mimeType:'text/plain',buffer:guard.bytes});
  await message('File staged in this browser. Save Changes sends it when delivery is connected.');assert.equal(guard.state.posts,0);
  await page.reload();await expect(button('Export Staged '+guard.name)).toBeVisible();
  assert.deepEqual(await download('Export Staged '+guard.name,'staged-export.txt'),guard.bytes);
  await message('Staged bytes exported. No cloud request was made.');
  const recovery=await download('Export Recovery Copy','before-delivery-recovery.json');
  assert.ok(!recovery.includes(Buffer.from(token)));assert.deepEqual(Buffer.from(JSON.parse(recovery).uploads[0].data,'base64'),guard.bytes);
  phase='connect';await button('Connection Details').click();await page.getByLabel('Session token for delivery',{exact:true}).fill(token);await button('Enable delivery for this session').click();
  await message('Saved. Use Save Changes to run one delivery cycle.');await expect(page.getByLabel('Session token for delivery',{exact:true})).toHaveValue('');await button('Close Connection Details').click();
  phase='empty baseline';await button('Read Attachments').click();await message('0 attachments read. No file mutation was sent.');assert.equal(guard.state.baseline,true);
  phase='upload';await page.getByRole('button',{name:/^Save Changes/}).click();await message('Queued supported changes confirmed by YouTrack. Auto-Sync preference unchanged.');assert.equal(guard.state.posts,1);
  phase='download';assert.deepEqual(await download('Download '+guard.name,'native-download.txt'),guard.bytes);await message('Attachment downloaded from verified current metadata.');
  evidence.attachmentId=guard.state.receipt;await screenshot('uploaded.png');
  phase='cancel deletion';await button('Remove '+guard.name).click();const dialog=page.getByRole('dialog',{name:'Queue deletion of this attachment?',exact:true});
  await expect(dialog).toContainText(guard.state.receipt);await expect(dialog).toContainText(guard.name);await expect(dialog).toContainText(alias);await expect(dialog).toContainText(guard.bytes.length+' bytes');await expect(dialog).toContainText('permanently deletes');await dialog.getByRole('button',{name:'Cancel',exact:true}).click();assert.equal(guard.state.deletes,0);
  phase='review deletion';await button('Remove '+guard.name).click();await expect(dialog).toContainText(guard.state.receipt);await button('Queue Attachment Deletion').click();
  await message('Attachment deletion queued. Connected Save Changes sends the reviewed request.');assert.equal(guard.state.deletes,0);guard.armDelete(guard.state.receipt);
  phase='delete';await page.getByRole('button',{name:/^Save Changes/}).click();await expect.poll(()=>guard.state.deletedInventory).toBe(true);await message('Queued supported changes confirmed by YouTrack. Auto-Sync preference unchanged.');assert.equal(guard.state.deletes,1);
  phase='disconnect';await button('Connection Details').click();await button('Disconnect delivery').click();await message('Disconnected. Queue and drafts kept; session token discarded.');await button('Close Connection Details').click();
  await page.reload();await expect(page.getByRole('switch',{name:'Auto-Sync Data',exact:true})).not.toBeChecked();await expect(button('Download '+guard.name)).toHaveCount(0);await screenshot('deleted-reloaded.png');
  await download('Export Recovery Copy','final-recovery.json');
  evidence.nativeAcceptance='PASS attachment transport only; MCP preservation readback pending';
  token='';
};
try { await main(); }
catch {
  guard?.halt(); evidence.nativeAcceptance='STOPPED'; evidence.stoppedAt=phase; process.exitCode=1;
  // Do not print Playwright errors: call logs can contain password values or signed URLs.
  if(page && output) {
    try {for(const label of ['YouTrack Permanent Token','Session token for delivery']) {const input=page.getByLabel(label,{exact:true});if(await input.count())await input.fill('');}await page.screenshot({path:join(output,'stopped.png'),fullPage:true});}catch{}
    try {const close=page.getByRole('button',{name:'Close Connection Details',exact:true});if(await close.isVisible())await close.click();const pending=page.waitForEvent('download',{timeout:5000});pending.catch(()=>{});await page.getByRole('button',{name:'Export Recovery Copy',exact:true}).click();await (await pending).saveAs(join(output,'stopped-recovery.json'));}catch{}
  }
}
finally {
  if(output)await writeFile(join(output,'result.json'),JSON.stringify(evidence,null,2));
  await context?.close().catch(()=>{});await browser?.close().catch(()=>{});
  process.stdout.write(JSON.stringify({result:evidence.nativeAcceptance,phase})+'\n');
}



