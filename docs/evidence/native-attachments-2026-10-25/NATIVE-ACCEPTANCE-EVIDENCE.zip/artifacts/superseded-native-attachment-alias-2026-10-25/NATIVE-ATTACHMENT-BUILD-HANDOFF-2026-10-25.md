# Native attachment runner build handoff - 2026-10-25

The standalone runner and offline guard tests are ready for Main Agent security review. No browser or live YouTrack request ran. No credential was read. Native acceptance remains unrun.

## Files and exact hashes

| File | SHA-256 |
| --- | --- |
| scripts/native-attachment-acceptance.mjs | 6769f3871f6a14416dd0202a59253a91e87577537d152e5f2053da13cda8d08f |
| scripts/native-attachment-guard.mjs | 0465e665c7cc02943198463587fe68b6a651ec3ccab845a4e6396afa72cf0f43 |
| scripts/native-attachment-guard.test.mjs | c7a6f9838dbf87ad86831c97cf6558106169e86a0894dca51ce5e29783d25c5a |

These three test-only files and this handoff are the only changes in this assignment. No package scripts, default suites, app code, build or deployment configuration changed. Expected deployed source is 36e748eaad7e360974c62c392a61c639ae19f804; documentation intake was b8accbaa312813ea712f6ae2a7db455e1d00717f. Main Agent must independently reconfirm deployed identity before execution; embedding the expected commit in a result is not deployment verification.

## Verification performed

`node scripts/native-attachment-guard.test.mjs`: 29 offline cases passed in the final run. Covers browser/fixture/run allowlists, exact fixture rewrite, real PMON and direct NPCD refusal, foreign origin, unknown query/duplicate fields, unsupported methods, redirect refusal, nonattachment mutations, unregistered file addresses, unexpected account query, old/unreviewed/repeated deletion, baseline requirement, nonempty baseline, HTTP failure, missing/changed multipart bytes/filename/content type, repeated POST, invalid receipt ID, exact registered signed address, foreign returned address, and the allowed sequence. Earlier runs were repeated only after targeted harness changes.

`node --check scripts/native-attachment-acceptance.mjs`: passed. The runner was not executed, including with fake credentials. No application suite/build ran because application code is unchanged and the assignment limits execution to offline guards.

Read complete Main Agent plan, auxiliary QA checklist, attachment requirements, existing synthetic UI tests and connected transport/delivery/UI controls. Applied repository Ponytail full and review guidance. Expected load is one sequential operator and one tiny file per fresh browser context. No same-time browser runs.

## Guard and evidence checklist

| Requirement | Implementation / pending proof |
| --- | --- |
| Keep production guards and real tasks unchanged | Only PMON-900001 synthetic task-context GETs are fulfilled; no real PMON request reaches native network. Its attachment URL maps to the selected NPCD fixture. |
| Exact browser/fixture pair | Chromium/NPCD-872 or Firefox/NPCD-873 only. New output directory required. |
| Secret safety | Opaque stdin only; bounded input; no arguments/files for credential, no console forwarding, traces/HAR/video, profiles or storage dumps. Debug logging environment flags cause refusal before input. Errors report only phase and STOPPED. Token fields cleared before screenshots. |
| Native transport and CORS | Account, attachment and file traffic uses route.continue only. Test-only fetch observer clones native JSON to register IDs/addresses before returning the unchanged Response. It requires native response.type=cors and app redirect:error/credentials:omit. No route.fetch, proxy or fulfilled native response. |
| Native mutation limit | Empty native baseline and account required, one exact multipart POST; only its returned numeric attachment ID may later be deleted once after UI review. Any guard failure halts subsequent traffic. |
| Exact multipart | Validates complete framing, single upload name, exact filename, MIME and bytes, allowing only optional final CRLF. Missing intercepted bytes fail closed. |
| Signed address protection | Only exact same-tenant file URL registered from the new file's metadata can be fetched. Signed query remains memory-only; receipts show a placeholder for file address. |
| Local stage/reload/export | Uses actual UI; compares exported bytes and recovery upload payload before connection. Pending runtime proof. |
| Actual upload/download confirmation | Uses actual Save and confirmed status text; unchanged app verifies metadata/account/SHA-256; runner independently compares downloaded bytes. Sanitized metadata, ID, account, method/status/path and browser CORS type retained. Pending runtime proof. |
| Cancel then review deletion | Checks dialog ID/name/task/size/permanence text; Cancel and queued state must leave zero DELETEs. Arms only exact returned ID after queue message, then explicit Save. Requires native empty post-delete inventory. Pending runtime proof. |
| Disconnect/reload | Actual disconnect message, empty file UI after reload and Auto-Sync switch OFF. Sharing is never enabled; all extension endpoints denied. Pending runtime proof. |
| Failure disposition | Halt network, clear visible token fields, capture screenshot and synthetic recovery when possible, close fresh context. No retry, resend or automatic deletion. Failed export is not reported as captured. |
| Fixture preservation | Before/after MCP checks remain Main Agent work; timestamps may change from attachment operations. Existing status receipts, text, State and hierarchy are outside runner mutation routes. |

## Reviewed invocations, not executed

Run from C:\Users\mrgen\ROMDex. Output parent must exist; choose never-used run and output names. Main Agent supplies the token privately to the process stdin and closes stdin. Do not put it in command text, command history, environment, a file or a transcript. Do not enable Playwright/Node debug logging.

```powershell
node scripts/native-attachment-acceptance.mjs --browser chromium --fixture NPCD-872 --run chromium-20261025-a --output docs/evidence/native-attachments-chromium-2026-10-25-a
```

Only after Chromium result and independent fixture preservation review:

```powershell
node scripts/native-attachment-acceptance.mjs --browser firefox --fixture NPCD-873 --run firefox-20261025-a --output docs/evidence/native-attachments-firefox-2026-10-25-a
```

Offline review command (no stdin/network/browser):

```powershell
node scripts/native-attachment-guard.test.mjs
```

Result files include original bytes, exported/downloaded bytes, recovery copies, screenshots and sanitized result.json. Recovery contains only this fresh synthetic workspace and exact operation receipts; it is not imported into real work. If a run stops after POST, retain the file and receipt for explicit review. Do not rerun with another name to bypass a nonempty baseline.

## Limits and review points

This demonstrates native attachment transport through the hosted origin with substituted task context. It does not prove native task reading/hierarchy, arbitrary NPCD support, physical Windows installation, or production cutover. Fresh automation contexts block service workers and use bundled Chromium/Firefox, not the owner's existing profiles. The native preflight/redirect behavior and full multipart availability still need runtime observation. If browser routing exposes OPTIONS to the guard it stops; the runner never synthesizes a native preflight response. A CORS failure is a stopped acceptance result, not permission to replace the native response.

Official Playwright [route.continue](https://playwright.dev/docs/api/class-route#route-continue) documents network continuation and same-protocol URL overrides. [Request](https://playwright.dev/docs/api/class-request#request-post-data-buffer) documents intercepted request data. Neither documentation nor offline tests substitute for native CORS verification; the browser observer requires a CORS Response.

Build-Audit Agent: Astra/low, reused under Main Agent selection for bounded calibration. Implementation produced three files and 29 passing offline cases; no model escalation. Precise token usage/cost comparison unavailable. Main Agent security review and Test-QA/live acceptance remain required. Production sharing stays OFF and SC-001 remains blocked separately.
