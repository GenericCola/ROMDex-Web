import assert from 'node:assert/strict';
import {createGuard,tenant,alias,metadataFields} from './native-attachment-guard.mjs';
const make=()=>createGuard({browser:'chromium',fixture:'NPCD-872',run:'offline'});
const list={url:`${tenant}/api/issues/${alias}/attachments?fields=${metadataFields}&$top=100&$skip=0`,method:'GET'};
const ready=()=>{const g=make();g.authorize(list);g.observe({kind:'inventory',status:200,value:[]});g.observe({kind:'account',status:200,value:{id:'1-1'}});return g;};
const post=g=>({url:`${tenant}/api/issues/${alias}/attachments?fields=id`,method:'POST',contentType:'multipart/form-data; boundary=abc',body:Buffer.concat([Buffer.from(`--abc\r\nContent-Disposition: form-data; name="upload"; filename="${g.name}"\r\nContent-Type: text/plain\r\n\r\n`),g.bytes,Buffer.from('\r\n--abc--\r\n')])});
let count=0;
const test=(name,fn)=>{fn();count++;};
const refuses=(request,setup=ready)=>{const g=setup();assert.throws(()=>g.authorize(typeof request==='function'?request(g):request));assert.equal(g.state.halted,true);};
test('fixture/browser allowlist',()=>{assert.throws(()=>createGuard({browser:'chromium',fixture:'NPCD-873',run:'x'}));assert.throws(()=>createGuard({browser:'firefox',fixture:'PMON-1',run:'x'}));assert.throws(()=>createGuard({browser:'chromium',fixture:'NPCD-872',run:'../x'}));});
test('exact list rewrites only fixture',()=>assert.equal(make().authorize(list).url,new URL(list.url.replace(alias,'NPCD-872')).href));
for(const request of [
 {...list,url:list.url.replace(alias,'PMON-1')}, {...list,url:list.url.replace(alias,'NPCD-872')},
 {...list,url:list.url.replace(tenant,'https://evil.invalid')}, {...list,url:list.url+'&extra=1'},
 {...list,url:list.url+'&fields=id'}, {...list,method:'PATCH'}, {...list,method:'OPTIONS'}, {...list,redirected:true},
 {url:tenant+'/api/issues/'+alias,method:'POST'}, {url:tenant+'/api/files/unregistered?signature=secret',method:'GET'},
 {url:tenant+'/api/users/me?fields=id,login',method:'GET'},
 {url:tenant+'/api/issues/'+alias+'/attachments/134-9',method:'DELETE'}
])test('refuse unsafe route/method',()=>refuses(request));
test('baseline required',()=>refuses(post,make));
test('nonempty baseline stops',()=>assert.throws(()=>make().observe({kind:'inventory',status:200,value:[{id:'old'}]})));
test('HTTP failure stops',()=>assert.throws(()=>make().observe({kind:'inventory',status:401,value:[]})));
for(const mutate of [p=>({...p,body:null}),p=>({...p,body:Buffer.concat([p.body,Buffer.from('extra')])}),p=>({...p,body:Buffer.from(p.body.toString().replace('filename="romdex','filename="other'))}),p=>({...p,body:Buffer.from(p.body.toString().replace('acceptance','wrong'))}),p=>({...p,contentType:'application/json'})])test('exact multipart refused',()=>refuses(g=>mutate(post(g))));
test('one post only',()=>{const g=ready();g.authorize(post(g));assert.throws(()=>g.authorize(post(g)));});
test('receipt and reviewed deletion only',()=>{const g=ready();g.authorize(post(g));g.observe({kind:'post',status:200,value:[{id:'134-1'}]});assert.throws(()=>g.authorize({url:tenant+'/api/issues/'+alias+'/attachments/134-1',method:'DELETE'}));});
test('successful exact sequence and no second delete',()=>{const g=ready();g.authorize(post(g));g.observe({kind:'post',status:200,value:[{id:'134-1'}]});const value={id:'134-1',name:g.name,size:g.bytes.length,author:{id:'1-1'},url:'/api/files/exact?signature=opaque'};g.observe({kind:'inventory',status:200,value:[value]});g.observe({kind:'metadata',status:200,value});assert.equal(g.authorize({url:tenant+value.url,method:'GET'}).kind,'file');g.armDelete('134-1');g.authorize({url:tenant+'/api/issues/'+alias+'/attachments/134-1',method:'DELETE'});g.observe({kind:'inventory',status:200,value:[]});assert.throws(()=>g.authorize({url:tenant+'/api/issues/'+alias+'/attachments/134-1',method:'DELETE'}));});
test('registered signed URL exact match',()=>{const g=ready();g.authorize(post(g));g.observe({kind:'post',status:200,value:[{id:'134-1'}]});g.observe({kind:'metadata',status:200,value:{id:'134-1',name:g.name,size:g.bytes.length,author:{id:'1-1'},url:'/api/files/exact?signature=opaque'}});assert.throws(()=>g.authorize({url:tenant+'/api/files/exact?signature=changed',method:'GET'}));});
test('invalid receipt ID',()=>{const g=ready();g.authorize(post(g));assert.throws(()=>g.observe({kind:'post',status:200,value:[{id:'../old'}]}));});
test('old deletion cannot arm',()=>{const g=ready();g.authorize(post(g));g.observe({kind:'post',status:200,value:[{id:'134-1'}]});assert.throws(()=>g.armDelete('134-2'));});
test('foreign file URL refused',()=>{const g=ready();g.authorize(post(g));g.observe({kind:'post',status:200,value:[{id:'134-1'}]});assert.throws(()=>g.observe({kind:'metadata',status:200,value:{id:'134-1',name:g.name,size:g.bytes.length,author:{id:'1-1'},url:'https://evil.invalid/api/files/x'}}));});
console.log(`${count} offline guard assertions passed; no browser or network executed.`);
