# Explicit local acceptance wrapper: saved credential stays in memory and a child stdin pipe.
import argparse, base64, ctypes, hashlib, json, pathlib, subprocess, sys, urllib.request
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

parser = argparse.ArgumentParser()
parser.add_argument('--browser', choices=['chromium', 'firefox'], required=True)
parser.add_argument('--fixture', choices=['NPCD-872', 'NPCD-873'], required=True)
parser.add_argument('--run', required=True)
a = parser.parse_args()
assert (a.browser, a.fixture) in [('chromium','NPCD-872'),('firefox','NPCD-873')]
assert 1 <= len(a.run) <= 40 and all(c in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in a.run)
root = pathlib.Path(r'C:\Users\mrgen\ROMDex')
parent = root / 'artifacts/native-attachments-2026-10-25'
output = parent / a.run
assert not output.exists(), 'Use a new evidence directory; no live retries.'
receipt_path = parent / (a.run + '-metadata.json')
assert not receipt_path.exists()
runner = root / 'scripts/native-attachment-acceptance.mjs'
assert runner.is_file()

class Blob(ctypes.Structure):
    _fields_ = [('cbData', ctypes.c_uint32), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]

def protected_key(raw):
    assert raw[:5] == b'DPAPI'
    raw = raw[5:]
    buf = ctypes.create_string_buffer(raw)
    source = Blob(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.windll.crypt32.CryptUnprotectData
    crypt.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(Blob)]
    crypt.restype = ctypes.c_int
    if not crypt(ctypes.byref(source), None, None, None, None, 0, ctypes.byref(result)):
        raise RuntimeError('Saved Windows credential could not be opened.')
    try:
        return ctypes.string_at(result.pbData, result.cbData)
    finally:
        free = ctypes.windll.kernel32.LocalFree
        free.argtypes = [ctypes.c_void_p]
        free.restype = ctypes.c_void_p
        free(result.pbData)

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError('Unexpected metadata redirect refused.')

phase = 'saved credential'
token = ''
try:
    profile = pathlib.Path(r'C:\Users\mrgen\AppData\Local\ROMDexDesktop\Data')
    wrapped = json.loads((profile / 'thegobindsingh-PMON/service/connection.encrypted').read_text(encoding='utf-8'))
    state = json.loads((profile / 'Runtime/thegobindsingh-PMON/Local State').read_text(encoding='utf-8'))
    assert wrapped['format'] == 'ROMDexElectronCredential/1'
    sealed = base64.b64decode(wrapped['bytes'], validate=True)
    assert sealed[:3] == b'v10'
    key = protected_key(base64.b64decode(state['os_crypt']['encrypted_key'], validate=True))
    token = AESGCM(key).decrypt(sealed[3:15], sealed[15:], None).decode('utf-8').strip()
    assert token and len(token) <= 8192 and not any(ord(c) < 33 or ord(c) > 126 for c in token)
    endpoint = 'https://thegobindsingh.youtrack.cloud/api/issues/' + a.fixture + '/extensionEndpoints/romdex-status-acceptance/status/assigned'
    def read_metadata():
        req = urllib.request.Request(endpoint, headers={'Authorization':'Bearer '+token,'Accept':'application/json','Cache-Control':'no-store'},method='GET')
        with urllib.request.build_opener(NoRedirect()).open(req, timeout=30) as response:
            value = json.load(response)
        assert value['id'] == a.fixture and value['schema'] == 1 and value['initialized'] is True and isinstance(value['receipt'],dict)
        return value
    phase = 'read-only metadata baseline'
    before = read_metadata()
    receipt = {'fixture':a.fixture,'browser':a.browser,'scope':'Read-only extension snapshot outside browser; not a CORS check. Runner owns attachment integration evidence.','before':before,'runnerSha256':hashlib.sha256(runner.read_bytes()).hexdigest()}
    parent.mkdir(parents=True,exist_ok=True)
    receipt_path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    phase = 'browser attachment acceptance'
    result = subprocess.run(['node',str(runner),'--browser',a.browser,'--fixture',a.fixture,'--run',a.run,'--output',str(output)],cwd=root,input=token,text=True,encoding='utf-8',capture_output=True)
    receipt['runnerExitCode'] = result.returncode
    phase = 'read-only metadata preservation'
    after = read_metadata()
    receipt['after'] = after
    receipt['metadataPreservedExceptIssueUpdated'] = {k:v for k,v in before.items() if k!='updated'} == {k:v for k,v in after.items() if k!='updated'}
    receipt_path.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'fixture':a.fixture,'browser':a.browser,'runnerExitCode':result.returncode,'metadataPreservedExceptIssueUpdated':receipt['metadataPreservedExceptIssueUpdated'],'evidence':str(output)}))
    # Do not echo arbitrary child diagnostics; signed URLs and token values stay out of tool output.
    sys.exit(result.returncode if receipt['metadataPreservedExceptIssueUpdated'] else 2)
except Exception as error:
    print(json.dumps({'stoppedAt':phase,'errorType':type(error).__name__,'secretPrinted':False}))
    sys.exit(1)