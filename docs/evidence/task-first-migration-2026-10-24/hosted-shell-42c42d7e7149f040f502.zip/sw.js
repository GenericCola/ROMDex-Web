const CACHE = "romdex-shell-42c42d7e7149f040f502";
const ASSETS = ["/404.html","/404/index.html","/__next.__PAGE__.txt","/__next._full.txt","/__next._tree.txt","/_next/static/QGuDAH5KegG76h82vKgKa/_buildManifest.js","/_next/static/QGuDAH5KegG76h82vKgKa/_clientMiddlewareManifest.js","/_next/static/QGuDAH5KegG76h82vKgKa/_ssgManifest.js","/_next/static/chunks/0cg8u_b11ir-j.js","/_next/static/chunks/0ciih05a3rs_7.js","/_next/static/chunks/0cz1d0mv5g_q7.js","/_next/static/chunks/0f0znr-3-3tug.js","/_next/static/chunks/0ijwgoq3tdmum.js","/_next/static/chunks/0khroturg-_it.js","/_next/static/chunks/0umf92h1sb77c.js","/_next/static/chunks/1mg_p74yzzn0w.js","/_next/static/chunks/1ndctpl5cgvh-.js","/_next/static/chunks/21yn-1ummw4jh.js","/_next/static/chunks/2_xf99yxhp4od.js","/_next/static/chunks/2dq55bxe-ulsc.js","/_next/static/chunks/2n5qeheznvl4u.js","/_next/static/chunks/3376x6dockopt.js","/_next/static/chunks/3itl84f1h31o8.js","/_next/static/chunks/3oyrkv53cue05.css","/_next/static/chunks/turbopack-2c3mg3r-05n1w.js","/_next/static/chunks/turbopack-3ntsfifkmjmhc.js","/_next/static/chunks/turbopack-worker-1hrsqshz0gfey.js","/_next/static/media/1bffadaabf893a1e-s.3-6t-g6q0vh0a.woff2","/_next/static/media/20aee433927f7d4b-s.22-vwy_zcz7be.woff2","/_next/static/media/256e1f7f180674ba-s.3_q_pmj-3v7pv.woff2","/_next/static/media/292081311a6a8abc-s.3z1vcboutudqk.woff2","/_next/static/media/2bbe8d2671613f1f-s.0k62hbripvv8p.woff2","/_next/static/media/2c55a0e60120577a-s.0-dom-5bn10r2.woff2","/_next/static/media/36363bfb06833f56-s.p.38hmww4cj4vme.woff2","/_next/static/media/4317bd468b03db68-s.2iw_c-zuq9o4-.woff2","/_next/static/media/5476f68d60460930-s.2uwcyprjm3xu3.woff2","/_next/static/media/68d403cf9f2c68c5-s.012bmydply3go.woff2","/_next/static/media/753b6407f468151f-s.11jlrhjosin9v.woff2","/_next/static/media/83afe278b6a6bb3c-s.p.2bn3s6zvc0dyp.woff2","/_next/static/media/9c72aa0f40e4eef8-s.1y4-pdgsjb-pw.woff2","/_next/static/media/a73419dd2ba2d841-s.p.2yee423r7ahpo.woff2","/_next/static/media/ad66f9afd8947f86-s.3lvt2whj97whp.woff2","/_next/static/media/b12e986493c137cf-s.2njitm-prmz2_.woff2","/_next/static/media/b2fa3ef4ca165ab4-s.12_ml6bnugnre.woff2","/_next/static/media/be3bf58b83159894-s.0kupvvif_223v.woff2","/_next/static/media/icon.0fael5y7mpg-j.svg","/_next/static/media/rdx.worker.0mdt8sfydhk-m.ts","/_not-found/__next._full.txt","/_not-found/__next._not-found.__PAGE__.txt","/_not-found/__next._tree.txt","/_not-found/index.html","/_not-found/index.txt","/assets/fonts/.gitkeep","/assets/images/.gitkeep","/favicon.ico","/foundation/__next._full.txt","/foundation/__next._tree.txt","/foundation/__next.foundation.__PAGE__.txt","/foundation/index.html","/foundation/index.txt","/icon.svg","/icons/apple-touch-icon.png","/icons/icon-192.png","/icons/icon-512.png","/icons/maskable-512.png","/icons/source.svg","/index.html","/index.txt","/manifest.webmanifest","/opengraph-image","/robots.txt","/romdex/npcdex-pokeball.svg","/romdex/standard-settings-icon.svg","/sitemap.xml"];
const INVENTORY = new Set(ASSETS);
const keyFor = (request) => {
  const url = new URL(request.url);
  if (
    request.method !== "GET" ||
    url.origin !== self.location.origin ||
    url.search ||
    request.headers.has("Authorization")
  )
    return null;
  let key = url.pathname;
  if (request.mode === "navigate" && !INVENTORY.has(key))
    key = key.endsWith("/") ? key + "index.html" : key + "/index.html";
  return INVENTORY.has(key) ? key : null;
};
self.addEventListener("install", (event) => {
  const precache = async () => {
    const cache = await caches.open(CACHE);
    try {
      await cache.addAll(ASSETS);
    } catch (error) {
      await caches.delete(CACHE);
      throw error;
    }
  };
  event.waitUntil(precache());
});
self.addEventListener("activate", (event) => {
  const activate = async () => {
    for (const name of await caches.keys())
      if (name.startsWith("romdex-shell-") && name !== CACHE)
        await caches.delete(name);
    await self.clients.claim();
  };
  event.waitUntil(activate());
});
self.addEventListener("fetch", (event) => {
  const key = keyFor(event.request);
  if (!key) return;
  const respond = async () =>
    (await (await caches.open(CACHE)).match(key)) ?? fetch(event.request);
  event.respondWith(respond());
});
self.addEventListener("message", (event) => {
  if (event.data?.type !== "ACTIVATE_UPDATE") return;
  const update = async () => {
    const windows = await self.clients.matchAll({
      type: "window",
      includeUncontrolled: true,
    });
    const scope = new URL(self.registration.scope);
    const otherWindows = windows.filter(
      (client) =>
        client.id !== event.source?.id && client.url.startsWith(scope.href),
    );
    if (otherWindows.length) {
      event.ports[0]?.postMessage({ blocked: true });
      return;
    }
    event.ports[0]?.postMessage({ blocked: false });
    await self.skipWaiting();
  };
  event.waitUntil(update());
});
